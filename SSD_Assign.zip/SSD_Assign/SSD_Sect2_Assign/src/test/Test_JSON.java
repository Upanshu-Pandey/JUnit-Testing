package test;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collection;
import java.util.Set;

import org.junit.jupiter.api.Test;

import json.*;

class Test_JSON {
	
	@SuppressWarnings( "unlikely-arg-type")
	
	@Test
	void JSONArray() throws JSONException {
		JSONArray arrayValue = JSONFactory.createArray(6);
		for(int i =10;i<16;i++) {
			arrayValue.addValue(i);
		}
		assertEquals("[10,11,12,13,14,15]",arrayValue.toString());
		assertTrue(arrayValue.equals(arrayValue));
		assertFalse(arrayValue.equals(null));
		assertFalse(arrayValue.equals(arrayValue.getClass()));
		assertEquals(arrayValue,arrayValue.asArray());
		assertTrue(arrayValue.isArray());
		assertEquals(JSONFactory.createNumber(14),arrayValue.get(4));
	}
	
	@Test
	void JSONNulltest() {
		JSONNull nullValue = JSONFactory.createNull();
		assertTrue(nullValue.isNull());
		assertFalse(nullValue.isArray());
		assertFalse(nullValue.isBoolean());
		assertFalse(nullValue.isNumber());
		assertFalse(nullValue.isObject());
		assertFalse(nullValue.isString());
		
		assertEquals(953,nullValue.hashCode());
		assertEquals("null",nullValue.toString());
		assertTrue(nullValue.equals(JSONFactory.createNull()));
		assertFalse(nullValue.equals(null));
	}
	
	@Test
	void JSONNumber() throws JSONException {
		
		JSONNumber doubleValue = JSONFactory.createNumber(69.2);
		assertFalse(doubleValue.equals(JSONFactory.createNumber(0)));
		assertTrue(doubleValue.equals(JSONFactory.createNumber(69.2)));
		assertTrue(doubleValue.equals(doubleValue));
		assertFalse(doubleValue.equals(null));
		assertFalse(doubleValue.equals(doubleValue.getClass()));
		
		JSONNumber minimumValLong = JSONFactory.createNumber(-3147483650L);
		JSONNumber intValue = JSONFactory.createNumber(20);
		JSONNumber maximumValLong = JSONFactory.createNumber(3147483649L);
		assertEquals(-3147483650L,minimumValLong.asLong());
		assertEquals(3147483649L,maximumValLong.asLong());
		assertEquals(20L,intValue.asLong());
		
		assertThrows(JSONException.class,()->doubleValue.asLong());
		
		JSONNumber floatValue = JSONFactory.createNumber(23.42f);
		assertEquals(20,intValue.asInteger());
		assertThrows(JSONException.class,()->doubleValue.asInteger());
		assertThrows(JSONException.class,()->floatValue.asInteger());
		
		JSONNumber shortValue = JSONFactory.createNumber(-8425);
		assertEquals(20,intValue.asShort());
		assertEquals(-8425,shortValue.asShort());
		assertThrows(JSONException.class,()->floatValue.asShort());
		
		JSONNumber byteValue = JSONFactory.createNumber(115);
		assertEquals(115,byteValue.asByte());
		assertThrows(JSONException.class,()->minimumValLong.asByte());
		assertThrows(JSONException.class,()->maximumValLong.asByte());
		
		
		assertTrue(doubleValue.isNumber());
		assertEquals(69.2,doubleValue.getNumber());
		assertEquals("69.2",doubleValue.toString());
		assertEquals(JSONFactory.createNumber(69.2).hashCode(),doubleValue.hashCode());
		
		assertEquals(69.2f,doubleValue.asFloat());
		assertEquals(-3147483649f,minimumValLong.asFloat());
		assertEquals(3147483648f,maximumValLong.asFloat());
		assertEquals(23.42f,floatValue.asFloat());
		assertEquals(20f,intValue.asFloat());
		
		assertEquals(69.2,doubleValue.asDouble());
		assertEquals(-3.14748365E9,minimumValLong.asDouble());
		assertEquals(3.147483649E9,maximumValLong.asDouble());
		assertEquals(23.420000076293945,floatValue.asDouble());
		assertEquals(20,intValue.asDouble());
			
	}
	
	@SuppressWarnings("unlikely-arg-type")
	@Test
	void JSONStringTest() throws JSONException {
		JSONString eschar = JSONFactory.createString("\u0018");	
		eschar.toString();
		JSONString stringValue = JSONFactory.createString("");
		JSONString stringValue1 = JSONFactory.createString("Zlatan Ibrahimovich");
		JSONString stringValue2 = JSONFactory.createString("\"\\\\\\\\/\b\f\n\r\t");
		
		assertEquals("\"\\\"\\\\\\\\\\\\\\\\\\/\\b\\f\\n\\r\\t\"",stringValue2.toString());
		assertEquals("\"\"",stringValue.toString());
		
		
		assertEquals("Zlatan Ibrahimovich",stringValue1.asString());
		
		assertEquals("Zlatan Ibrahimovich",stringValue1.getString());
		
		assertTrue(stringValue1.equals(JSONFactory.createString("Zlatan Ibrahimovich")));
		
		assertTrue(stringValue1.isString());
		
		assertEquals(-1177857071,stringValue1.hashCode());
		
		assertTrue(stringValue1.equals(stringValue1));
		assertFalse(stringValue1.equals(null));
		
		assertFalse(stringValue1.equals(stringValue1.getClass()));
		assertEquals("\"Zlatan Ibrahimovich\"",stringValue1.toString());
		
		
	}
	
	@Test
	void JSONBooleantest() {
		JSONBoolean boolobj = JSONFactory.createBoolean(false);
		
		assertTrue(boolobj.equals(JSONFactory.createBoolean(false)));
		
		assertFalse(boolobj.equals(null));
		
		assertTrue(boolobj.isBoolean());
		
		assertFalse(boolobj.asBoolean());
		
		assertEquals("false",boolobj.toString());
		
		JSONBoolean boolobj2 = JSONFactory.createBoolean(true);
		
		assertEquals("true",boolobj2.toString());
		
		assertEquals(1237,boolobj.hashCode());
		
		assertEquals(1231,boolobj2.hashCode());
		
	}
	
	@Test
	void JSONObjectTest() throws FileNotFoundException, IOException, JSONException {
		JSONValue parseFileObject = JSONParser.parseFile("example.json");
		JSONObject jsonValue = parseFileObject.asObject();
		JSONObject jsonValue2 = JSONFactory.createObject(parseFileObject.asObject());
		JSONObject jsonValue2Copy = jsonValue2.copy();
		assertEquals(11,jsonValue.size());
		assertEquals(jsonValue.values(),jsonValue.values());
		
		assertEquals(2095311018,jsonValue2.hashCode());
		assertTrue(jsonValue2.equals(jsonValue2Copy));
		assertFalse(jsonValue2.equals(null));
		assertFalse(jsonValue2.equals(jsonValue2.getClass()));
		assertTrue(jsonValue2.equals(jsonValue2));
		
		assertTrue(jsonValue2.hasMember("prop1"));
		assertFalse(jsonValue2.hasMember("property"));
		assertFalse(jsonValue2.hasBooleanMember(null));
		assertTrue(jsonValue2.hasBooleanMember("prop4"));
		assertFalse(jsonValue2.hasBooleanMember("prop5"));
		assertFalse(jsonValue2.hasBooleanMember("prop1"));
        
		JSONArray arr = JSONFactory.createArray();
		arr.addValue(69);
		arr.addValue("budhha");
		arr.addValue(true);
		arr.addValue(69.69);
		assertEquals(4,arr.size());
		jsonValue2.addMember("array4",arr);
		assertEquals(12,jsonValue2.size());
		jsonValue2.addMember("jsonObjProp", jsonValue);
		
		assertEquals(13,jsonValue2.size());
		assertThrows(JSONException.class,()->jsonValue2.asArray());
		assertThrows(JSONException.class,()->jsonValue2.asString());
		assertThrows(JSONException.class,()->jsonValue2.asLong());
		
	}
	
	
	
	@Test
	void JSONParseTest() throws IOException, JSONException {
		JSONValue valueObject = JSONParser.parse("{ }");
		assertNotNull(valueObject);
		assertTrue(valueObject.isObject());
		assertEquals("{}",valueObject.toString());
		
		JSONValue fileObj = JSONParser.parseFile("example.json");

		assertNotNull(fileObj);
		assertTrue(fileObj.isObject());
		
		JSONObject jsonObj = fileObj.asObject();
		
		JSONValue prop1 = jsonObj.getMember("prop1");
		assertTrue(prop1.isString());
		assertEquals("A string", prop1.asString());
	
		JSONValue prop2 = jsonObj.getMember("prop2");
		assertTrue(prop2.isNumber());
		assertEquals(0, prop2.asInteger());
		
		JSONValue prop3 = jsonObj.getMember("prop3");
		assertTrue(prop3.isNumber());
		assertEquals(3.142, prop3.asDouble());
		
		JSONValue prop4 = jsonObj.getMember("prop4");
		assertTrue(prop4.isBoolean());
		assertEquals(true, prop4.asBoolean());

		
		
		
		assertThrows(JSONException.class,()->{JSONParser.parseFile("Test1.json");});
		assertThrows(JSONException.class,()->{JSONParser.parseFile("Test2.json");});
		assertThrows(JSONException.class,()->{JSONParser.parseFile("Test3.json");});		
		assertThrows(JSONException.class,()->{JSONParser.parseFile("Test4.json");});
		assertThrows(JSONException.class,()->{JSONParser.parseFile("Test5.json");});
		
		char c = '\u003E';
		assertThrows(JSONException.class,()->JSONParser.parse("{\"Unexpected Error\" :\""+c));
		assertThrows(JSONException.class,()->JSONParser.parse("{\"Unexpected Error\" :$"));
		assertThrows(JSONException.class,()->JSONParser.parse("{\"Unexpected Error\" :-"));
		
		assertThrows(JSONException.class, ()->JSONParser.parse("{\"Unexpected Error\" : \"\\u123\"}"));
		assertThrows(JSONException.class, ()->JSONParser.parse("{\"Unexpected Error\" : \"\\u\"}"));
		assertThrows(JSONException.class, ()->JSONParser.parse("{\"Unexpected Error\" :t}"));
		assertThrows(JSONException.class, ()->JSONParser.parse("{\"Unexpected Error\" :f}"));
		assertThrows(JSONException.class, ()->JSONParser.parse("{\"Unexpected Error\" :n}"));
		assertThrows(JSONException.class,()->JSONParser.parse("{\"Unexpected Error\" :\"\\x}"));
		assertThrows(JSONException.class,()->JSONParser.parse("{\"Unexpected Error\" :\""));
		assertThrows(JSONException.class,()->JSONParser.parse("{\"Unexpected Error\" : [1,]}"));
		
		
	}
	
	
	
	
	
}
